﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Threading;
using System.Web;
using System.Web.Http;
using System.Web.Mvc;
using System.Web.Routing;
using System.Web.Security;
using AppComponents.Raven;
using AppComponents.Web;
using $safeprojectname$.App_Start;
using System.Web.Optimization;

using Shrike.UserManagement.BusinessLogic.Business;

using log4net.Config;
using AppComponents;

namespace $safeprojectname$
{
    using Shrike.Tenancy.Web;
    using log4net;
    using System.IO;
    using System.Text;

    // Note: For instructions on enabling IIS6 or IIS7 classic mode, 
    // visit http://go.microsoft.com/?LinkId=9394801
    public class MvcApplication : System.Web.HttpApplication
    {
        private readonly ILog log = ClassLogger.Create(typeof(MvcApplication));

        protected void Application_Start()
        {
            //Configure logging
            XmlConfigurator.Configure();
            ClassLogger.Configure();

            AreaRegistration.RegisterAllAreas();

            WebApiConfig.Register(GlobalConfiguration.Configuration);
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);

            RoleBusinessLogic.CreateRolesAndNavigationInfo();
        }

        /// <summary>
        /// Retrieves the IPrincipal from ApplicationUser documents by using its principalId which should be unique
        /// </summary>
        /// <param name="principalId">unique id for a user for the hole system</param>
        /// <returns>The IPrincipal instance from ApplicationUser</returns>
        private static IPrincipal GetUserFromPrincipalId(string principalId)
        {
            using (var session = DocumentStoreLocator.ResolveOrRoot(CommonConfiguration.CoreDatabaseRoute))
            {
                var user = session.Load<ApplicationUser>(principalId);
                return user;
            }
        }

        //validate that a user when logged will not try to use another tenant
        protected void Application_AuthenticateRequest(object sender, EventArgs e)
        {
            //Since this method is called on every request
            //we want to fail as early as possible
            if (!Request.IsAuthenticated) return;//Check issues when not authenticated and doing logoff on old page

            //Forms auth ticket
            var formsId = Context.User.Identity as FormsIdentity;
            if (formsId == null) return;

            var currentTenant = TenantHelper.GetCurrentTenantFormUrl(this.Context);

            if (TenantHelper.ValidateTenant(currentTenant, formsId))
            {
                return;
            }

            //The user is attempting to access a different tenant
            //than the one they logged into so sign them out
            //an and redirect to the home page of the new tenant
            //where they can sign back in (if they are authorized!)
            
            FormsAuthentication.SignOut();
            HttpContext.Current.User = new GenericPrincipal(new GenericIdentity(string.Empty), new string[] { });
            this.Response.Redirect("/" + currentTenant);
        }

        protected void Application_PostAuthenticateRequest(object sender, EventArgs e)
        {
            var id = Context.User.Identity as FormsIdentity;
            if (id == null)
            {
                return;
            }

            var principal = GetUserFromPrincipalId(id.Name);
            if (principal != null)
            {
                Thread.CurrentPrincipal = HttpContext.Current.User = principal;
            }
        }

        protected void Application_Error(object sender, EventArgs e)
        {
            bool? pageNotFound = null;

            var exception = Server.GetLastError();

            var httpException = exception as HttpException;

            //Text Code Lines for to find the library or file that is causing reflection problems in the project.
            var reflectionException = exception as System.Reflection.ReflectionTypeLoadException;
            if (reflectionException != null)
            {
                var sb = new StringBuilder();
                foreach (var exSub in reflectionException.LoaderExceptions)
                {
                    sb.AppendLine(exSub.Message);
                    var exFileNotFound = exSub as FileNotFoundException;
                    if (exFileNotFound != null)
                    {
                        if (!string.IsNullOrEmpty(exFileNotFound.FusionLog))
                        {
                            sb.AppendLine("Fusion Log:");
                            sb.AppendLine(exFileNotFound.FusionLog);
                        }
                    }

                    sb.AppendLine();
                }

                // The message indicating the library or file is write in the project log.
                log.Error("Reflection Error: " + sb);
            }

            //Response.Clear();
            //Server.ClearError();

            if (httpException != null && httpException.GetHttpCode() == 404)
            {
                switch (httpException.GetHttpCode())
                {
                    case 403:
                        pageNotFound = false;
                        break;
                    case 404:
                        pageNotFound = true;
                        break;
                }
            }

            var err = exception.ToString();

            if (exception.InnerException != null)
            {
                err += "\nInnerException: " + exception.InnerException;
            }

            this.log.Error("Url Controller: " + HttpContext.Current.Request.Url);
            this.log.Error(err);

            if (pageNotFound.HasValue)
            {
                this.Response.RedirectToRoute(
                    string.Empty,
                    pageNotFound.Value
                        ? new { controller = "Errors", action = "Http400" }
                        : new { controller = "Errors", action = "Http403" });
            }
            else this.Response.RedirectToRoute(string.Empty, new { controller = "Errors", action = "Error" });
        }
    }
}