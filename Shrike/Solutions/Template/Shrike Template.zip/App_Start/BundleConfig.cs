﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Optimization;

namespace $safeprojectname$.App_Start
{
    public static class BundleConfig
    {
        public static void RegisterBundles(BundleCollection bundles)
        {
            bundles.Add(new StyleBundle("~/Content/css")
                .Include("~/Content/Theme/Default/Site.css")
                .Include("~/Content/Theme/Default/styles/jquery-ui-1.9.2.custom.css")
                .Include("~/Content/Theme/Default/styles/jquery.jscrollpane.css")
                .Include("~/Content/Theme/Default/styles/jquery.multiselect.css")
                .Include("~/Content/Theme/Default/styles/jquery.multiselect.filter.css")
                );

            //jquery bundle
            bundles.Add(new ScriptBundle("~/bundles/jquery")
                .Include("~/Scripts/jquery-{version}.js"));

            //jqueryvalidation
            bundles.Add(new ScriptBundle("~/bundles/jqueryval").Include(
                           "~/Scripts/jquery.unobtrusive*",
                           "~/Scripts/jquery.validate*",
                           "~/Scripts/jquery.dynamic.validate.unobtrusive.js"));

            //scripts for managing tags, taggable entities
            bundles.Add(new ScriptBundle("~/bundles/customtags")
                .Include("~/Scripts/jquery.jscrollpane.js")
                .Include("~/Scripts/jquery.jscrollpane.min.js")
                .Include("~/Scripts/jquery.multiselect.js")
                .Include("~/Scripts/jquery.multiselect.filter.js")
                .Include("~/Scripts/jquery.carouFredSel-6.2.0-packed.js"));

            //jqueryui
            bundles.Add(new ScriptBundle("~/bundles/jqueryui").Include(
                        "~/Scripts/jquery-ui-{version}.js", "~/Scripts/jquery-ui.unobtrusive-{version}.js"));

            bundles.Add(new ScriptBundle("~/bundles/customs")
                .Include("~/Scripts/shrike-functions.js"));

            bundles.Add(new ScriptBundle("~/bundles/GridRowSelection")
                .Include("~/Scripts/shrike-grid-row-selection.js"));

            bundles.Add(new ScriptBundle("~/bundles/Tag")
                .Include("~/Scripts/jquery.carouFredSel-6.2.0-packed.js")
                .Include("~/Scripts/jquery.multiselect.filter.js")
                .Include("~/Scripts/jquery.multiselect.js")
                .Include("~/Scripts/jquery.calculation.js"));
        }
    }
}