﻿$(document).ready(function () {
        $("table tbody tr.selectedRow").removeClass("selectedRow");
        $("table tbody tr:eq(0)").addClass("selectedRow");
        $("table tbody tr").each(function () {
            if ($(this).hasClass("selectedRow")) {
                var name = $(this).find("#idSystemOwnerInv").val();
                var datasent = $(this).find("#dataSent").text();
                $("#SelectedRow").val(name);
                //fillDataSentEmail(name,datasent);
            }
            FormatLabelByHeight($(this));
        });
});

$("table tr").click(function () {
    $("table tbody tr.selectedRow").removeClass("selectedRow");
    $(this).toggleClass('selectedRow');
    var name = $(this).find("#idSystemOwnerInv").val();
    var datasent = $(this).find("#dataSent").text();
    $("#SelectedRow").val(name);
    //fillDataSentEmail(name, datasent);
    SelectedItemAction();
});

